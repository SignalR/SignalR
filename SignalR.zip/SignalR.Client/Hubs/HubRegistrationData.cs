﻿namespace SignalR.Client.Hubs
{
    public class HubRegistrationData
    {
        public string Name { get; set; }
    }
}
