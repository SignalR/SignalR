﻿using System.Reflection;

[assembly: AssemblyVersion("0.5.1.0")]