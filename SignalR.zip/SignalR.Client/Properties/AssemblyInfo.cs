﻿using System.Reflection;

[assembly: AssemblyTitle("SignalR.Client")]
[assembly: AssemblyDescription(".NET client for SignalR")]
