﻿namespace SignalR.Client
{
    public enum ConnectionState
    {
        Connecting,
        Connected,
        Reconnecting,
        Disconnecting,
        Disconnected
    }
}
