﻿namespace SignalR.Client.Transports.ServerSentEvents
{
    public enum EventType
    {
        Id,
        Data
    }
}
