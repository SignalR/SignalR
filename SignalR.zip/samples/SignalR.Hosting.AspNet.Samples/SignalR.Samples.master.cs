﻿using System;

namespace SignalR.Samples.SignalRSamples
{
    public partial class SignalRSamples : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}