﻿
namespace SignalR.Samples.Streaming
{
    public class Streaming : PersistentConnection
    {
    }
}