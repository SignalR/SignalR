﻿namespace SignalR
{
    public enum CommandType
    {
        AddToGroup,
        RemoveFromGroup,
        Disconnect,
        Abort
    }
}
