﻿namespace SignalR.Infrastructure
{
    public enum ServerCommandType
    {
        RemoveConnection
    }
}
