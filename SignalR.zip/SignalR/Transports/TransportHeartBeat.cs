﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using SignalR.Infrastructure;

namespace SignalR.Transports
{
    /// <summary>
    /// Default implementation of <see cref="ITransportHeartBeat"/>.
    /// </summary>
    public class TransportHeartBeat : ITransportHeartBeat
    {
        private readonly SafeSet<ITrackingConnection> _connections = new SafeSet<ITrackingConnection>(new ConnectionIdEqualityComparer());
        private readonly ConcurrentDictionary<ITrackingConnection, ConnectionMetadata> _connectionMetadata = new ConcurrentDictionary<ITrackingConnection, ConnectionMetadata>(new ConnectionIdEqualityComparer());
        private readonly Timer _timer;
        private readonly Timer _beatTimer;
        private readonly Timer _keepAliveTimer;
        private readonly IConfigurationManager _configurationManager;
        private readonly IServerCommandHandler _serverCommandHandler;
        private readonly string _serverId;

        private int _running;
        private int _keepAliveRunning;
        private TimeSpan? _lastKeepAlive;

        /// <summary>
        /// Initializes and instance of the <see cref="TransportHeartBeat"/> class.
        /// </summary>
        /// <param name="resolver">The <see cref="IDependencyResolver"/>.</param>
        public TransportHeartBeat(IDependencyResolver resolver)
        {
            _configurationManager = resolver.Resolve<IConfigurationManager>();
            _serverCommandHandler = resolver.Resolve<IServerCommandHandler>();
            _serverId = resolver.Resolve<IServerIdManager>().ServerId;

            _serverCommandHandler.Command = ProcessServerCommand;

            // REVIEW: When to dispose the timers?
            _beatTimer = new Timer(Beat,
                               null,
                               _configurationManager.HeartBeatInterval,
                               _configurationManager.HeartBeatInterval);

            _keepAliveTimer = new Timer(KeepAlive, null, new TimeSpan(0, 0, 1), new TimeSpan(0, 0, 1));
        }

        private void ProcessServerCommand(ServerCommand command)
        {
            switch (command.Type)
            {
                case ServerCommandType.RemoveConnection:
                    // Only remove connections if this command didn't originate from the owner
                    if (!command.IsFromSelf(_serverId))
                    {
                        RemoveConnection((string)command.Value);
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Adds a new connection to the list of tracked connections.
        /// </summary>
        /// <param name="connection">The connection to be added.</param>
        public void AddConnection(ITrackingConnection connection)
        {
            UpdateConnection(connection);

            // Remove the metadata for new connections
            ConnectionMetadata old;
            _connectionMetadata.TryRemove(connection, out old);
            var metadata = new ConnectionMetadata();
            if (_connectionMetadata.TryAdd(connection, metadata))
            {
                metadata.UpdateKeepAlive(_configurationManager.KeepAlive);
            }
        }

        private void RemoveConnection(string connectionId)
        {
            // Remove the connection
            RemoveConnection(new ConnectionReference(connectionId));
        }

        /// <summary>
        /// Removes a connection from the list of tracked connections.
        /// </summary>
        /// <param name="connection">The connection to remove.</param>
        public void RemoveConnection(ITrackingConnection connection)
        {
            // Remove the connection and associated metadata
            _connections.Remove(connection);
            ConnectionMetadata old;
            _connectionMetadata.TryRemove(connection, out old);
        }

        /// <summary>
        /// Updates an existing connection and it's metadata.
        /// </summary>
        /// <param name="connection">The connection to be updated.</param>
        public void UpdateConnection(ITrackingConnection connection)
        {
            // Remove and re-add the connection so we have the correct object reference
            _connections.Remove(connection);
            _connections.Add(connection);
        }

        /// <summary>
        /// Marks an existing connection as active.
        /// </summary>
        /// <param name="connection">The connection to mark.</param>
        public void MarkConnection(ITrackingConnection connection)
        {
            // See if there's an old metadata value
            ConnectionMetadata oldMetadata;
            _connectionMetadata.TryGetValue(connection, out oldMetadata);
            
            // Mark this time this connection was used
            var metadata = _connectionMetadata.GetOrAdd(connection, _ => new ConnectionMetadata());
            if (oldMetadata != null)
            {
                // Use the same initial time (if it exists)
                metadata.Initial = oldMetadata.Initial;
            }

            metadata.LastMarked = DateTime.UtcNow;
        }

        private void KeepAlive(object state)
        {
            if (Interlocked.Exchange(ref _keepAliveRunning, 1) == 1)
            {
                Trace.TraceInformation("SIGNALR: KeepAlive timer handler took longer than current interval");
                return;
            }

            try
            {
                TimeSpan? keepAlive = _configurationManager.KeepAlive;
                if (keepAlive == null)
                    return;

                if ((_lastKeepAlive == null) || (_lastKeepAlive.Value.CompareTo(keepAlive.Value) != 0))
                {
                    //set/update the interval
                    _lastKeepAlive = keepAlive;
                    //_keepAliveTimer.Change(_lastKeepAlive.Value, _lastKeepAlive.Value);
                }

                foreach (var connection in _connections.GetSnapshot())
                {
                    if (!connection.IsAlive)
                        continue;

                    // The connection is still alive so we need to keep it alive with a server side "ping".
                    // This is for scenarios where networing hardware (proxies, loadbalancers) get in the way
                    // of us handling timeout's or disconencts gracefully

                    ConnectionMetadata metadata;
                    if (_connectionMetadata.TryGetValue(connection, out metadata) &&
                        DateTime.UtcNow >= metadata.KeepAliveTime)
                    {
                        connection.KeepAlive(keepAlive);
                        metadata.UpdateKeepAlive(keepAlive);
                        MarkConnection(connection);
                    }

                }
            }
            catch (Exception ex)
            {
                Trace.TraceError("SignalR error during keep alive heart beat on background thread: {0}", ex);
            }
            finally
            {
                Interlocked.Exchange(ref _keepAliveRunning, 0);
            }
        }



        private void Beat(object state)
        {
            if (Interlocked.Exchange(ref _running, 1) == 1)
            {
                Trace.TraceInformation("SIGNALR: TransportHeatBeat timer handler took longer than current interval");
                return;
            }

            try
            {
                foreach (var connection in _connections.GetSnapshot())
                {
                    if (!connection.IsAlive)
                    {
                        // The transport is currently disconnected, it could just be reconnecting though
                        // so we need to check it's last active time to see if it's over the disconnect
                        // threshold
                        TimeSpan elapsed;
                        if (TryGetElapsed(connection, metadata => metadata.LastMarked, out elapsed))
                        {
                            // The threshold for disconnect is the transport threshold + (potential network issues)
                            var threshold = connection.DisconnectThreshold + _configurationManager.DisconnectTimeout;

                            if (elapsed < threshold)
                            {
                                continue;
                            }
                        }

                        try
                        {
                            // Remove the connection from the list
                            RemoveConnection(connection);

                            // Fire disconnect on the connection
                            connection.Disconnect();
                        }
                        catch
                        {
                            // Swallow exceptions that might happen during disconnect
                        }
                    }
                    else
                    {
                        TimeSpan elapsed;
                        if (!connection.IsTimedOut &&
                            TryGetElapsed(connection, metadata => metadata.Initial, out elapsed) &&
                            elapsed >= _configurationManager.ConnectionTimeout)
                        {
                            // If we're past the expiration time then just timeout the connection                            
                            connection.Timeout();

                            RemoveConnection(connection);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError("SignalR error during transport heart beat on background thread: {0}", ex);
            }
            finally
            {
                Interlocked.Exchange(ref _running, 0);
            }
        }

        private bool TryGetElapsed(ITrackingConnection connection, Func<ConnectionMetadata, DateTime> selector, out TimeSpan elapsed)
        {
            ConnectionMetadata metadata;
            if (_connectionMetadata.TryGetValue(connection, out metadata))
            {
                // Calculate how long this connection has been inactive
                elapsed = DateTime.UtcNow - selector(metadata);
                return true;
            }

            elapsed = TimeSpan.Zero;
            return false;
        }

        private class ConnectionIdEqualityComparer : IEqualityComparer<ITrackingConnection>
        {
            public bool Equals(ITrackingConnection x, ITrackingConnection y)
            {
                return String.Equals(x.ConnectionId, y.ConnectionId, StringComparison.OrdinalIgnoreCase);
            }

            public int GetHashCode(ITrackingConnection obj)
            {
                return obj.ConnectionId.GetHashCode();
            }
        }

        private class ConnectionMetadata
        {
            public ConnectionMetadata()
            {
                Initial = DateTime.UtcNow;
                LastMarked = DateTime.UtcNow;
            }

            public DateTime LastMarked { get; set; }
            public DateTime Initial { get; set; }
            public DateTime KeepAliveTime { get; set; }

            public void UpdateKeepAlive(TimeSpan? keepAliveInterval)
            {
                if (keepAliveInterval == null)
                {
                    return;
                }

                KeepAliveTime = DateTime.UtcNow + keepAliveInterval.Value;
            }
        }
    }
}