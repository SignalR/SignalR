﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("SignalR.AspNet")]
[assembly: AssemblyDescription("Asp.Net host for SignalR")]
[assembly: AssemblyVersion("0.5.1.0")]