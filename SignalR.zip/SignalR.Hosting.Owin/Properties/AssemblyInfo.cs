﻿using System.Reflection;


[assembly: AssemblyTitle("SignalR.Owin")]
[assembly: AssemblyDescription("Owin host for SignalR")]
[assembly: AssemblyVersion("0.5.1.0")]