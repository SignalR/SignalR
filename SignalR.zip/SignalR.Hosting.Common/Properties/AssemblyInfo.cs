﻿using System.Reflection;

[assembly: AssemblyTitle("SignalR.Hosting.Common")]
[assembly: AssemblyDescription("Assembly containing common components for implementing SignalR hosts.")]
[assembly: AssemblyVersion("0.5.1.0")]
