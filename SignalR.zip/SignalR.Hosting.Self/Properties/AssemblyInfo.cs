﻿using System.Reflection;


[assembly: AssemblyTitle("SignalR.Hosting.Self")]
[assembly: AssemblyDescription("HttpListener host for SignalR")]
[assembly: AssemblyVersion("0.5.1.0")]
